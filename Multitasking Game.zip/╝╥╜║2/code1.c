#include"common.h"
#include"lcd.h"

#define Game2Speed 10
#define Game4Speed 100

int Game4Pattern[2] = {0x80,0x01};
int LineArr[L_MAX] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

void CleanRow(void);
void Game4P(int r1,int r2);
void Player4(int n);
void lineP1(void);
void Port_Init(void);
void Game4Pass(int);
int Game4Check(int, int, int);
void LineP3(int r, int count);
void Player3(int position);
void Timer_Init(void);
void Timer(void);

int Count_Value = 0;
int second = 00;
int min = 00;
int GameOver=0;
int on =1, off=0;
int n=0;
int time = 1;


ISR(TIMER0_OVF_vect)
{	
	TCNT0 = 100; // 10msec
	Count_Value++;
	if(Count_Value % 10 ==0 ) n++; // 0.1�� ���� n�� ���� ���Ѽ� ������ �ӵ��� �ð��� Ÿ�̸ӿ� �����.
	if(Count_Value >= 100)
	{
		second++;
		Count_Value = 0;
	}
}

int main(void)
{
	
	int k=0, i=0, position[2], r1[4], r2[2];
	int pass=0;
	int line[4];
	int Game2Count=1;
	char key, key0=0;
	int Game2=0, Game4=0, delay=0;

	Port_Init();
	Timer_Init();
	LCD_initialize();
	sei();//���ͷ�Ʈ ���
	
	position[1]=1;	
	position[0]=0;
	for(n=0;n<4;n++) r1[n] = rand()%(L_MAX);
	for(n=0;n<2;n++) r2[n] = rand()%2;
	line[0]=0;
	line[3]=2;
	line[2]=4;
	line[1]=6;
	while(1)
	{
		if(GameOver==0)
		{
			LCD_string(0x80, "Start");
			_delay_ms(1000);
			LCD_clear();
		}
		while(GameOver==0)
		{
			if((PINC & 0x80)==0) return 0; 
			while(1)
			{
				Timer(); //LCD �ð� ǥ��
				if(second==30 && min==1) Game2 = 1; // 1�� 30�ʵڿ� Game2 ����
				if(second==30) Game4 = 1; //30�� �ڿ� Game4 ����
				
				//----------------------------------------------------------Game2
				if(Game2 == 1)
				{
					for(i=0;i<Game2Count; i++)
					{
						if(line[i]==7)
							if(r1[i]==position[0]) { PORTC = 0x7f; cli(); GameOver=1; } // Game2 ���� üũ
					}

					if(n%Game2Speed==0 && delay==0) // ��ֹ��� ��ĭ�� �̵��Ѵ�.
					{
						delay=1;
						for(i=0;i<4; i++)
						{
							if(line[i]<(L_MAX-1))	
							{
								line[i]++;
							} else if (line[i] == L_MAX-1)
							{
								line[i]=0;
								r1[i] = rand()%(L_MAX);
								if(Game2Count<4) Game2Count++;
							}
						}
					}
					if(n%Game2Speed==1) delay =0; // if ���� �ð����� ���� �ߺ����� ����

					for(i=0;i<Game2Count;i++) LineP3(r1[i], line[i]);
					Player3(position[0]);
				}

				if(GameOver==1) break;


				//-----------------------------------------------------Game4		

				if(Game4 == 1)
				{
					if(n%Game4Speed==(Game4Speed-1) && pass == 0)
					{
						if(Game4Check(r2[0],r2[1], position[1]) == 1) { PORTC = 0x7f; cli(); GameOver=1; }
						r2[0] = rand()%2;
						r2[1] = rand()%2;
						pass=on;
					}
			
					if(pass==0)	{ Game4P(r2[0],r2[1]); Player4(position[1]); }
					else {
						if(k<100) { Game4Pass(position[1]); k++; }
						else { k=0; }
					}
					if(n%Game4Speed==1) pass=0;
				}

				if(GameOver==1) break;
				//-----------------------------------------------------


				key = key_scan();
				if(key == key0) continue; // Ű�е带 �� �������� �ȵθ� �ȵ��ư���
				switch(key)
				{
					case '9': position[1]=1;
					break;
					case '7': position[1]=2;
					break;
					case '3': position[1]=3;
					break;
					case '1': position[1]=4;
					break;
					case '2': if(position[0]>0) position[0]--;
					break;
					case '8': if(position[0]<(L_MAX-1)) position[0]++;
					break;			
					default:
					break;
				}
		
				key0 = key;
			}
			if(GameOver==1) break;
		}
		LCD_clear();
		Timer(); // ��������� ����Ѵ�
		LCD_string(0xc0, "8:restart  0:end");
		_delay_ms(1000);
		key = key_scan();
		if(key == '8') // 8�� ������ �����
		{
			n=0;
			GameOver=0;
			min=0;
			second=0;
			Count_Value=0;
			position[1]=1;	
			position[0]=0;
			for(n=0;n<4;n++) r1[n] = rand()%(L_MAX);
			for(n=0;n<2;n++) r2[n] = rand()%2;
			line[0]=0;
			line[3]=2;
			line[2]=4;
			line[1]=6;
			Game2=0;
			Game4=0;
			sei();
		}
		if(key == '0') // 0�� ������ ���� ����
		{
			LCD_clear();
			break;
		}	
	}
	return 0;
}


void lineP1()
{
	ROW2 = 0x00;
	COL2 = 0xff;
	_delay_ms(time);
	CleanRow();
}

void LineP3(int r, int count)
{
	ROW1 = LineArr[r];
	COL1 = ~LineArr[count];
	_delay_ms(time);
	CleanRow();
	return;
}


void Game4P(int r1,int r2)
{
	ROW2 = Game4Pattern[r1];
	COL2 = ~Game4Pattern[r2];
	_delay_ms(time);
	CleanRow();
}



void Player3(int position)
{
	ROW1 = LineArr[position];
	COL1 = ~LineArr[7];
	_delay_ms(time);
	CleanRow();
}
 
void Timer(void)
{
		if(second > 59)
		{
			second = 0;
			min++;
		}

		if(min > 59)
		{
			min = 0;
		}


		char_position(10,0);
		LCD_data((second%10)+48);

		char_position(9,0);
		LCD_data((second/10)+48);

		char_position(8,0);
		LCD_data(':');

		char_position(7,0);
		LCD_data((min%10)+48);

		char_position(6,0);
		LCD_data((min/10)+48);

		char_position(5,0);
		LCD_data(':');

		char_position(4,0);
		LCD_data('e');

		char_position(3,0);
		LCD_data('m');

		char_position(2,0);
		LCD_data('i');

		char_position(1,0);
		LCD_data('t');
}



void Game4Pass(int position)
{
	switch(position)
	{
		case 1 :
			ROW2 = 0x08;
			COL2 = ~0x38;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x18;
			_delay_ms(time);
			ROW2 = 0x20;
			COL2 = ~0x08;
			_delay_ms(time);
			break;
		case 2 :
			ROW2 = 0x08;
			COL2 = ~0x1c;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x18;
			_delay_ms(time);
			ROW2 = 0x20;
			COL2 = ~0x10;
			_delay_ms(time);
			break;
		case 3 :
			ROW2 = 0x04;
			COL2 = ~0x08;
			_delay_ms(time);
			ROW2 = 0x08;
			COL2 = ~0x18;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x38;
			_delay_ms(time);
			break;
		case 4 :
			ROW2 = 0x04;
			COL2 = ~0x10;
			_delay_ms(time);
			ROW2 = 0x08;
			COL2 = ~0x18;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x1c;
			_delay_ms(time);
			break;
	}
	CleanRow();
}

void Player4(int n)
{
	switch(n)
	{
		case 1 :
			ROW2 = 0x08;
			COL2 = ~0x38;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x08;
			_delay_ms(time);
			ROW2 = 0x20;
			COL2 = ~0x08;
			_delay_ms(time);
			break;
		case 2 :
			ROW2 = 0x08;
			COL2 = ~0x1c;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x10;
			_delay_ms(time);
			ROW2 = 0x20;
			COL2 = ~0x10;
			_delay_ms(time);
			break;
		case 3 :
			ROW2 = 0x04;
			COL2 = ~0x08;
			_delay_ms(time);
			ROW2 = 0x08;
			COL2 = ~0x08;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x38;
			_delay_ms(time);
			break;
		case 4 :
			ROW2 = 0x04;
			COL2 = ~0x10;
			_delay_ms(time);
			ROW2 = 0x08;
			COL2 = ~0x10;
			_delay_ms(time);
			ROW2 = 0x10;
			COL2 = ~0x1c;
			_delay_ms(time);
			break;
	}
	CleanRow();
}

