#ifndef __COMMON1_H__
#define __COMMON1_H__

#define F_CPU 16000000UL //
#include<avr/io.h>
#include<util/delay.h>
#include <avr/interrupt.h>
#include<stdlib.h>
#define L_MAX 8
#define Game1Speed 200
#define Game3Speed 100

#define ROW1 PORTD
#define COL1 PORTE
#define ROW2 PORTA
#define COL2 PORTB

#define Game3Max 3

#endif
