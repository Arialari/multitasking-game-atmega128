#include"common.h"
#include"lcd.h"

void LCD(void)
{
	LCD_string(0x80, "I m hungry");
	_delay_ms(1000);
}



void LCD_command(unsigned char command)
{
	PORTG = 0x00;
	PORTG = 0x01;
	PORTC = command;
	PORTG = 0x00;
	_delay_us(50);
	PORTG = 0x00;	
}

void LCD_data(unsigned char data)
{
	PORTG = 0x02;
	PORTG = 0x03;
	PORTC = data;
	PORTG = 0x02;
	_delay_us(50);
	PORTG = 0x00;
}

void LCD_clear()
{
	LCD_command(0x01);
	_delay_ms(2);
}

void LCD_initialize(void)
{
	PORTG = 0x03;
	PORTG = 0x02;
	_delay_ms(2);
	LCD_command(0x38);
	LCD_command(0x0c);
	LCD_command(0x06);
	LCD_clear();
}

void LCD_string(unsigned char command, char *string)
{
	LCD_command(command);
	while(*string != '\0')
	{
		LCD_data(*string);
		string++;
	}
}

void char_position(char x, char y)
{
	unsigned char position;

	if(y>1) y=1;
	if(x>15) x=15;

	position = y ? x+0xc0 : x+0x80;

	LCD_command(position);
}
