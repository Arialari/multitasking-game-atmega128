#ifndef __COMMON_H__
#define __COMMON_H__

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include<stdlib.h>

#define L_MAX 8

#define ROW1 PORTA
#define COL1 PORTB
#define ROW2 PORTD
#define COL2 PORTE



#endif
