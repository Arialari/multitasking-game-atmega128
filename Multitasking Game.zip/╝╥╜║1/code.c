#include"common1.h"

int LineArr[L_MAX] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
int Mask = 0xff;
int game1pattern[L_MAX-1] = {0xfc,0xf9,0xf3,0xe7,0xcf,0x9f,0x3f};
int game3pattern[Game3Max] = {0x80,0xc0,0xe0};

void lineP1(int r, int count);
void lineP2(int r, int count);
void player1(int position);
void player2(int position);
int key_scan(void);
void CleanRow(void);
void Port_Init(void);

int Gamefast = 1;
int time = 3;
int stay=3, low=2, high=1, off=0; 
int JumpSpeed=5; // �����Ҽ��� ������
int JumpHeight=4;
int on=1;

int second=0;
int Count_Value=0;

ISR(TIMER0_OVF_vect)
{
	TCNT0 = 100; // 10msec
	Count_Value++;
	if(Count_Value >= 100)
	{
		second++;
		Count_Value = 0;
	}
}

int main(void)
{

	Port_Init();
	Timer_Init();
	sei();

	int n=0, k, position[2];
	int r[3], line[3];
	int jump=0, staycount=0;
	int Start=0;
	int Game3=0;
	int GameOver=0;
	
	char key, key0=0;	

	r[0]=rand()%(L_MAX-1);
	r[1]=rand()%(L_MAX-1);
	r[2]=rand()%Game3Max;
	line[0]=0;
	line[1]=4;
	line[2]=7;
	position[0]=0;
	position[1]=7;
	while(1)
	{
	
		for(n=0;n<1200000;n++)
		{
			if(second==60) { Game3=1; time=1; }	// 1�е� Game3 ����
			
			for(k=0;k<2;k++) { //Game3 üũ
				if(line[k] == 7 && Game3 == 1) {
					if(!(position[0] == r[k] || position[0] == (r[k]+1))) {  GameOver=1; cli(); }
				}
			}
			if(line[2] == 0) { //Game1 üũ
				if((LineArr[position[1]] & game3pattern[r[2]]) != 0) {  GameOver=1; cli(); }
			}
			
			//--------------------------------------------------------------------------------

			if(jump!=0) // Game1�� ���� �κ�
			{
				if(jump==high)
				{
					if(n%JumpSpeed==0)
					{
						if(position[1]>JumpHeight)
						{
							position[1]--; // ���� ������ increase
						}
					}
					if(position[1] == JumpHeight) jump=stay;
				} else if(jump==low)
				{
					if(n%JumpSpeed==0)
					{
						if(position[1]<7)
						{
							position[1]++;
						}
					}
			
					if(position[1] == 7) jump=off;
				} else if(jump==stay)
				{
					if(staycount==500) {staycount=0; jump=low;}
					staycount++;
				}
			}

			//if((PINC & 0x80)==0) { GameOver=1; cli();} //�������� ��ĵ
		
			if(GameOver==1) break;
			//--------------------------------------------------- ��ºκ�
			if(Game3 == 1) // Game3 ��� �κ�
			{
				lineP1(r[0],line[0]);
				player1(position[0]);	
				lineP1(r[1],line[1]);
			}
			lineP2(r[2],line[2]); // Game1 ��ºκ�
			player2(position[1]); 
			key = key_scan();
			_delay_ms(1);
			// ----------------------------------------------------- ���� ���� �κ�
			if(n%Game1Speed==0) // Game1 ��ĭ �����̱�
			{
				for(k=0;k<2;k++)
				{
					if(line[k]<(L_MAX-1)) line[k]++;
					else if (line[k] == (L_MAX-1)) {
						line[k]=0;
						r[k] = rand()%(L_MAX-1);
					}
				}
			}
			if(n%Game3Speed==0) // Game3 ��ĭ �����̱�
			{
				if(line[2]>0) line[2]--;
				else if (line[2] == 0) { line[2]=7; r[2] = rand()%Game3Max; jump=low; staycount=0;}
			}

			if(key == key0) continue; // Ű�е带 �� �������� �ȵθ� �ȵ��ư���
			switch(key)
			{
				case '4': if(position[0]>0) position[0]--;
				break;
				case '6': if(position[0]<(L_MAX-1)) position[0]++;
				break;
				case '5': if(jump==0) jump=high;
				break;			
				default:
				break;
			}
			key0 = key;
		}
		_delay_ms(1000);
		key = key_scan();
		if(key == '8') // 8�� ������ ���� �����
		{
			n=0;
			GameOver=0;
			second=0;
			Count_Value=0;
			r[0]=rand()%(L_MAX-1);
			r[1]=rand()%(L_MAX-1);
			r[2]=rand()%Game3Max;
			line[0]=0;
			line[1]=4;
			line[2]=7;
			position[0]=0;
			position[1]=7;
			Game3=0;
			sei();
			time=3;
		}
		if(key == '0') // 0�� ������ ���� ����
		{
			break;
		}	
	}
	return 0;
}

void lineP1(int r, int count)
{
	ROW1 = LineArr[count];
	COL1 = ~(Mask & game1pattern[r]);
	_delay_ms(time);
	CleanRow();
	return;
}

void player1(int position)
{
	ROW1 = LineArr[7];
	COL1 = ~(Mask & LineArr[position]);
	_delay_ms(time);
	CleanRow();
}

void lineP2(int r, int count)
{
	ROW2 = Mask & game3pattern[r];
	COL2 = ~LineArr[count];
	_delay_ms(time);
	CleanRow();
	return;
}

void player2(int position)
{
	ROW2 = LineArr[position];
	COL2 = ~LineArr[0];
	_delay_ms(time);
	CleanRow();
}

void CleanRow(void)
{
	ROW1 = 0x00;
	COL1 = 0xff;
	ROW2 = 0x00;
	COL2 = 0xff;
}

int key_scan(void)
{
	char key_table[] = "123456789*0#";
	unsigned char i, j;

	for(i=0; i<3; i++)
	{
		PORTF |= 0x07;
		PORTF &= ~(0x01<<i);
		for(j=0; j<4; j++)
		{
			if((PINF & (0x08<<j)) == 0)
			return key_table[j*3 + i];
		}
	}
     return 0;
}

void Port_Init(void)
{
	DDRA = 0Xff;
	DDRB = 0xff;
	DDRF = 0x07;
	DDRD = 0xff;
	DDRE = 0xff;
	DDRF = 0x07;
	DDRG = 0x0c;
	PORTF = 0xff;
	PORTC = 0x01;
	PORTG = 0x00;
}

void Timer_Init(void)
{
	
	TCCR0 = (1<<CS02) | (1<<CS01) | (1<<CS00); //ǥ�ظ��, ���ֺ� 1024
	TCNT0 = 100; // 10msec
	TIMSK = (1<<TOIE0); //Ÿ�̸� �����÷� ���ͷ�Ʈ ���
}


