#ifndef __LCD_H__
#define __LCD_H__

void LCD(void);
void LCD_command(unsigned char command);
void LCD_data(unsigned char data);
void LCD_clear();
void LCD_initialize(void);
void LCD_string(unsigned char command, char *string);
void char_position(char x, char y);

#endif
