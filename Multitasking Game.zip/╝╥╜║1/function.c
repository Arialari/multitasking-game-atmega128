#include"common.h"
#include"lcd.h"

void CleanRow(void)
{
	ROW1 = 0x00;
	COL1 = 0xff;
	ROW2 = 0x00;
	COL2 = 0xff;
}


int key_scan(void)
{
	char key_table[] = "123456789*0#";
	unsigned char i, j;

	for(i=0; i<3; i++)
	{
		PORTF |= 0x07;
		PORTF &= ~(0x01<<i);
		for(j=0; j<4; j++)
		{
			if((PINF & (0x08<<j)) == 0)
			return key_table[j*3 + i];
		}
	}
     return 0;
}

int Game4Check(int r1, int r2, int position)
{
	int check;

	if(r1 == 0)
	{
		if(r2 == 0)
		{
			check = 1;
		} else {
			check = 2;
		}
	} else {
		if(r2 == 0)
		{
			check = 3;
		} else {
			check = 4;
		}
	}

	if (check != position) return 1;
	else return 0;
}

void Port_Init(void)
{
	DDRA = 0xff;
	DDRB = 0xff;
	DDRF = 0x07;
	DDRD = 0xff;
	DDRE = 0xff;
	PORTF = 0xff;
	DDRG = 0x03;
	DDRC = 0xff;
	PORTC = 0x00;
}

void Timer_Init(void)
{
	
	TCCR0 = (1<<CS02) | (1<<CS01) | (1<<CS00); //ǥ�ظ��, ���ֺ� 1024
	TCNT0 = 100; // 10msec
	TIMSK = (1<<TOIE0); //Ÿ�̸� �����÷� ���ͷ�Ʈ ���
}
